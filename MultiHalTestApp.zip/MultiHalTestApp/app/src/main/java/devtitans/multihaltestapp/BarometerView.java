package devtitans.multihaltestapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class BarometerView extends View {

    private Paint paint;
    private float pressure;

    public BarometerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint();
        paint.setColor(Color.BLACK);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Desenha a escala
        canvas.drawLine(0, 0, canvas.getWidth(), 0, paint);
        canvas.drawLine(0, 0, 0, canvas.getHeight(), paint);

        // Desenha a coluna de pressão
        float height = (float) (pressure / 100) * canvas.getHeight();
        canvas.drawRect(0, canvas.getHeight() - height, canvas.getWidth(), canvas.getHeight(), paint);

        // Desenha a coluna vermelha
        float red = (float) (pressure / 1000) * 255;
        paint.setColor(Color.rgb(red, 0, 0));
        canvas.drawRect(0, canvas.getHeight() - height, canvas.getWidth(), canvas.getHeight(), paint);
 
    }

    public void setPressure(int pressure) {
        this.pressure = pressure;
        invalidate();
    }
}

