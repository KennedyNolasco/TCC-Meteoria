package devtitans.multihaltestapp;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private SensorManager sensorManager;
    private ViewPager2 viewPager;
    private List<Fragment> fragments;
    private TabLayout tabLayout;
    public String lightString = "";
    public String tempString = "";
    public String humiString = "";
    public String presString = "";
    public String rainString = "";
    public String groundString = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);
        fragments = new ArrayList<>();
        //Com base na ordem em que os fragments foram adicionados o títulos e tabs serão ajustados.
        fragments.add(new SummaryFragment()); //fragments(0)
        fragments.add(new LightFragment()); //fragments(1)
        fragments.add(new AirHumidityFragment()); //fragments(2)
        fragments.add(new SoilMoistureFragment()); //fragments(3)
        fragments.add(new PressureFragment()); //fragments(4)
        fragments.add(new TemperatureFragment()); //fragments(5)
        fragments.add(new RainFragment()); //fragments(6)

        viewPager.setAdapter(new CustomPageAdapter(this, fragments));
        // Vincular o ViewPager ao TabLayout
        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> tab.setText(getTabTitle(position))
        ).attach();

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);


        List<Sensor> lightList = sensorManager.getSensorList(Sensor.TYPE_LIGHT);
        List<Sensor> humiList = sensorManager.getSensorList(Sensor.TYPE_RELATIVE_HUMIDITY);
        List<Sensor> tempList = sensorManager.getSensorList(Sensor.TYPE_AMBIENT_TEMPERATURE);
        List<Sensor> presList = sensorManager.getSensorList(Sensor.TYPE_PRESSURE);
        List<Sensor> rainList = sensorManager.getSensorList(Sensor.TYPE_DEVICE_PRIVATE_BASE);
        String lightString = "";
        String tempString = "";
        String humiString = "";
        String presString = "";
        String rainString = "";
        String groundString = "";

        for (Sensor el : rainList) {
            lightString += el.getName() + " " + el.getStringType() + "\n";
            Log.println(Log.INFO, "RAIN_TEST", el.getName());
        }

        // O sensor de luminosidade padrão vai ser o primeiro da lista, por isso o SmartLamp é o segundo
        Sensor light = lightList.size() > 1 ?  lightList.get(1) : lightList.get(0);
        Sensor humi = humiList.get(0);
        Sensor temp = tempList.get(0);
        Sensor pres = presList.get(0);
        Sensor rain = null;
        if(rainList != null  && rainList.size() > 0) {
            rain = rainList.get(0);
        }
        Sensor ground =  humiList.size() > 1 ?  humiList.get(1) : humiList.get(0) ;

        sensorManager.registerListener(lightListener, light, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(humiListener, humi, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(tempListener, temp, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(presListener, pres, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(rainListener, rain, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(groundListener, ground, SensorManager.SENSOR_DELAY_NORMAL);

    }

    private String getTabTitle(int position) {
        // Substitua com os títulos reais para cada aba
        switch (position) {
            case 0:
                return "Resumo";
            case 1:
                return "Luminosidade";
            case 2:
                return "Umidade do Ar";
            case 3:
                return "Umidade do Solo";
            case 4:
                return "Pressão";
            case 5:
                return "Temperatura";
            case 6:
                return "Chuva";
            default:
                return "";
        }
    }

    // Método na MainActivity para atualizar o LightFragment com um novo valor
    public void updateLightFragments(int newLightValue) {
        LightFragment lightFragment = (LightFragment) fragments.get(1); // Assumindo que LightFragment é o segundo fragmento
        SummaryFragment summaryFragment = (SummaryFragment) fragments.get(0); // Assumindo que SummaryFragment é o primeiro fragmento
        lightFragment.updateLightValue(newLightValue);
        summaryFragment.updateLightValue(newLightValue);


    }

    public void updateAirHumidityFragment(int newValue) {
        AirHumidityFragment airHumidityFragment = (AirHumidityFragment) fragments.get(2); // Assumindo que LightFragment é o segundo fragmento
        SummaryFragment summaryFragment = (SummaryFragment) fragments.get(0); // Assumindo que SummaryFragment é o primeiro fragmento
        airHumidityFragment.updateAirHumidityValue(newValue);
        summaryFragment.updateAirHumidtyValue(newValue);
    }

    public void updateSoilMoistureFragment(int newValue) {
        SoilMoistureFragment soilMoistureFragment = (SoilMoistureFragment) fragments.get(3);
        SummaryFragment summaryFragment = (SummaryFragment) fragments.get(0); // Assumindo que SummaryFragment é o primeiro fragmento
        soilMoistureFragment.updateValue(newValue);
        summaryFragment.updateSoilMoistureValue(newValue);
    }

    public void updatePressureFragment(int newValue) {
        PressureFragment pressureFragment = (PressureFragment) fragments.get(4);
        SummaryFragment summaryFragment = (SummaryFragment) fragments.get(0); // Assumindo que SummaryFragment é o primeiro fragmento
        pressureFragment.updateValue(newValue);
        summaryFragment.updatePressureValue(newValue);
    }

    public void updateTemperatureFragment(int newValue) {
        TemperatureFragment temperatureFragment = (TemperatureFragment) fragments.get(5);
        SummaryFragment summaryFragment = (SummaryFragment) fragments.get(0); // Assumindo que SummaryFragment é o primeiro fragmento
        temperatureFragment.updateValue(newValue);
        summaryFragment.updateTemperatureValue(newValue);
    }

    public void updateRainFragment(int newValue) {
        RainFragment rainFragment = (RainFragment) fragments.get(6);
        SummaryFragment summaryFragment = (SummaryFragment) fragments.get(0); // Assumindo que SummaryFragment é o primeiro fragmento
        rainFragment.updateValue(newValue);
        summaryFragment.updateRainValue(newValue);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_summary:
                viewPager.setCurrentItem(0, true);
                return true;
            case R.id.action_light:
                viewPager.setCurrentItem(1, true);
                return true;
            case R.id.action_air_humidity:
                viewPager.setCurrentItem(2, true);
                return true;
            case R.id.action_soil_moisture:
                viewPager.setCurrentItem(3, true);
                return true;
            case R.id.action_pressure:
                viewPager.setCurrentItem(4, true);
                return true;
            case R.id.action_temperature:
                viewPager.setCurrentItem(5, true);
                return true;
            case R.id.action_rain:
                viewPager.setCurrentItem(6, true);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sensorManager != null) {
            sensorManager.unregisterListener(lightListener);
            sensorManager.unregisterListener(tempListener);
            sensorManager.unregisterListener(humiListener);
            sensorManager.unregisterListener(presListener);
            sensorManager.unregisterListener(rainListener);
            sensorManager.unregisterListener(groundListener);
        }
    }

    private SensorEventListener lightListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            // The value of the first subscript in the values array is the current light intensity
            float value = event.values[0];
            updateLightFragments((int) value);
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    private SensorEventListener humiListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float value = event.values[0];
            Log.println(Log.INFO, "test", String.valueOf(value));
            updateAirHumidityFragment((int) value);
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    private SensorEventListener tempListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float value = event.values[0];
            Log.println(Log.INFO, "test", String.valueOf(value));
            updateTemperatureFragment((int) value);

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    private SensorEventListener presListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float value = event.values[0];
            Log.println(Log.INFO, "test", String.valueOf(value));
            updatePressureFragment((int) value);
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    private SensorEventListener rainListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float value = event.values[0];
            Log.println(Log.INFO, "test", String.valueOf(value));
            updateRainFragment((int) value);

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    private SensorEventListener groundListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float value = event.values[0];
            Log.println(Log.INFO, "test", String.valueOf(value));
            updateSoilMoistureFragment((int) value);
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };
}