package devtitans.multihaltestapp;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.time.LocalDate;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link LightFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LightFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private ImageView imageView;
    private TextView textView;
    View rootView;

    public LightFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment LuminosityFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static LightFragment newInstance(String param1, String param2) {
        LightFragment fragment = new LightFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_light, container, false);
        imageView = rootView.findViewById(R.id.lightAnimationImageView);
        textView = rootView.findViewById(R.id.textLuminosity);
        return rootView;
    }

    // Método para atualizar a imagem com base no valor do sensor
    private void updateImage(int lightSensorValue) {
        if(imageView == null) {
            Log.e("test", "Light imageView is null");
            return;
        }
        // Escolhe a imagem com base no valor do sensor
        int drawableResourceId;
        if (lightSensorValue == 0) {
            drawableResourceId = R.drawable.lamp_0;
            rootView.setBackgroundColor(Color.DKGRAY);
        } else if (lightSensorValue < 12) {
            drawableResourceId = R.drawable.lamp_1;
            rootView.setBackgroundColor(Color.DKGRAY);
        } else if (lightSensorValue < 24) {
            drawableResourceId = R.drawable.lamp_2;
            rootView.setBackgroundColor(Color.DKGRAY);
        } else if (lightSensorValue < 36) {
            drawableResourceId = R.drawable.lamp_3;
            rootView.setBackgroundColor(Color.WHITE);
        } else if (lightSensorValue < 48) {
            drawableResourceId = R.drawable.lamp_4;
            rootView.setBackgroundColor(Color.WHITE);
        } else if (lightSensorValue < 60) {
            drawableResourceId = R.drawable.lamp_5;
            rootView.setBackgroundColor(Color.WHITE);
        } else if (lightSensorValue < 72) {
            drawableResourceId = R.drawable.lamp_6;
            rootView.setBackgroundColor(Color.WHITE);
        } else if (lightSensorValue < 84) {
            drawableResourceId = R.drawable.lamp_7;
            rootView.setBackgroundColor(Color.WHITE);
        } else {
            drawableResourceId = R.drawable.lamp_8;
            rootView.setBackgroundColor(Color.WHITE);
        }
        // Define a imagem no ImageView
        imageView.setImageResource(drawableResourceId);
    }

    private void updateText(int lightSensorValue) {
        if(textView == null) {
            Log.e("test", "Light textView is null");
            return;
        }
        textView.setText("Luminosidade: " + lightSensorValue);
    }

    public void updateLightValue(int lightSensorValue) {
        updateImage(lightSensorValue);
        updateText(lightSensorValue);
    }
}