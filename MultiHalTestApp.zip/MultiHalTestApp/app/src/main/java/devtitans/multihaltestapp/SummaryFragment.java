package devtitans.multihaltestapp;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SummaryFragment extends Fragment {

    // Adicione os widgets ou variáveis necessárias para exibir as informações de resumo
    private TextView tvLuminosity;
    private TextView tvAirHumidity;
    private TextView tvSoilMoisture;
    private TextView tvTemperature;
    private TextView tvPressure;

    private TextView tvRain;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_summary, container, false);

        // Inicialize os widgets com base nos IDs definidos no layout do fragmento
        tvLuminosity = rootView.findViewById(R.id.textLuminosity); //tvLuminosity == text view luminosity
        tvAirHumidity = rootView.findViewById(R.id.textHumidity);
        tvSoilMoisture = rootView.findViewById(R.id.textSoilMoisture);
        tvTemperature = rootView.findViewById(R.id.textTemperature);
        tvPressure = rootView.findViewById(R.id.textPressure);
        tvRain = rootView.findViewById(R.id.textRain);

        /* Substitua as chamadas abaixo com as funções ou dados reais
        displayLuminosity(80); // Exemplo de valor de luminosidade
        displayAirHumidity(65); // Exemplo de valor de umidade do ar
        displaySoilHumidity(40); // Exemplo de valor de umidade do solo
        displayTemperature(25); // Exemplo de valor de temperatura
        displayPressure(1010); // Exemplo de valor de pressão atmosférica
        displayRain(100);
*/
        return rootView;
    }

    // Métodos para exibir informações específicas
    public void updateLightValue(int value) {
        if(tvLuminosity == null) {
            Log.i("test", "tvLuminosity is null");
            return;
        }
        tvLuminosity.setText(value + " lux");
    }

    public void updateAirHumidtyValue(int value) {
        if(tvAirHumidity == null) {
            Log.i("test", "tvAirHumidity is null");
            return;
        }
        tvAirHumidity.setText(value + "%");
    }

    public void updateSoilMoistureValue(int value) {
        if(tvSoilMoisture == null) {
            Log.i("test", "tvSoilMoisture is null");
            return;
        }
        tvSoilMoisture.setText(value + "%");
    }

    public void updateTemperatureValue(int value) {
        if(tvTemperature == null) {
            Log.i("test", "tvTemperature is null");
            return;
        }
        tvTemperature.setText(value + "°C");
    }

    public void updatePressureValue(int value) {
        if(tvPressure == null) {
            Log.i("test", "tvPressure is null");
            return;
        }
        tvPressure.setText(value + " hPa");
    }

    public void updateRainValue(int value) {
        if(tvRain == null) {
            Log.i("test", "tvRain is null");
            return;
        }
        tvRain.setText(value + " ");
    }
}
