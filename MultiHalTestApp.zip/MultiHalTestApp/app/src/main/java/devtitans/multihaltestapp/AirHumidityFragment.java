package devtitans.multihaltestapp;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AirHumidityFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AirHumidityFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private View rootView;
    private ImageView imageView;
    private TextView textView;


    public AirHumidityFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AirHumidityFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AirHumidityFragment newInstance(String param1, String param2) {
        AirHumidityFragment fragment = new AirHumidityFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_air_humidity, container, false);
        imageView = rootView.findViewById(R.id.airHumidityImageView);
        textView = rootView.findViewById(R.id.textAirHumidity);
        return rootView;
    }

    private void updateImage(int sensorValue) {

    }

    private void updateText(int sensorValue) {
        Log.i("test", "sensor value: " + sensorValue);
        int color;
        if(rootView == null) {
            Log.e(""+ this.getClass().getName(), "rootView is null");
            return;
        }
        if(textView == null) {
            Log.e(""+ this.getClass().getName(), "textView is null");
            return;
        }

        if(sensorValue < 12) {
            color = Color.parseColor("#D12B27");
            rootView.setBackgroundColor(color);
            textView.setText("Umidade do ar: " + sensorValue + "%\n" + "Emergência: Tempo muito seco!");
        } else if(sensorValue < 21) {
            color = Color.parseColor("#F4511E");
            rootView.setBackgroundColor(color);
            textView.setText("Umidade do ar: " + sensorValue + "%\n" + "Alerta: Tempo seco!");
        } else if(sensorValue < 31) {
            color = Color.parseColor("#FDD835");
            rootView.setBackgroundColor(color);
            textView.setText("Umidade do ar: " + sensorValue + "%\n" + "Atenção: Tempo seco!");
        } else if(sensorValue < 60) {
            color = Color.parseColor("#FDD835");
            rootView.setBackgroundColor(color);
            textView.setText("Umidade do ar: " + sensorValue + "%\n" + "Observação: Tempo seco!");
        }  else if(sensorValue < 70) {
            color = Color.parseColor("#43A047");
            rootView.setBackgroundColor(color);
            textView.setText("Umidade do ar: " + sensorValue + "%\n" + "Umidade do ar adequada!");
        }  else if(sensorValue < 80) {
            color = Color.parseColor("#3949AB");
            rootView.setBackgroundColor(color);
            textView.setText("Umidade do ar: " + sensorValue + "%\n" + "Ar úmido!");
        } else {
            color = Color.parseColor("#8E24AA");
            rootView.setBackgroundColor(color);
            textView.setText("Umidade do ar: " + sensorValue + "%\n" + "Ar muito úmido!");
        }
        textView.setGravity(Gravity.CENTER);
    }

    public void updateAirHumidityValue(int sensorValue) {
        Log.println(Log.INFO, "test", "updatedAirHumidityValue: " + String.valueOf(sensorValue));
        updateImage(sensorValue);
        updateText(sensorValue);
    }

}