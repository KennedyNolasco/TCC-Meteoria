package devtitans.multihaltestapp;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link TemperatureFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TemperatureFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private TextView textView;
    private TextView textViewLabel;
    private ImageView imageView;
    private View rootView;

    public TemperatureFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment TemperatureFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static TemperatureFragment newInstance(String param1, String param2) {
        TemperatureFragment fragment = new TemperatureFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_temperature, container, false);
        imageView = rootView.findViewById(R.id.temperatureImageView);
        textView = rootView.findViewById(R.id.textTemperature);
        textViewLabel = rootView.findViewById(R.id.labelTemperature);
        return rootView;
    }

    private void updateImage(int sensorValue) {

    }

    private void updateText(int sensorValue) {
        int color;
        if(textView == null) {
            Log.e("test", "Temp TextView is null");
            return;
        }
        textView.setText(sensorValue + " ºC");
        textView.setGravity(Gravity.CENTER);
        if(sensorValue < 6) {
            color = Color.parseColor("#35329d");
            rootView.setBackgroundColor(color);
            textView.setTextColor(Color.WHITE);
            textViewLabel.setTextColor(Color.WHITE);
        } else if(sensorValue < 9) {
            color = Color.parseColor("#0000fd");
            rootView.setBackgroundColor(color);
            textView.setTextColor(Color.WHITE);
            textViewLabel.setTextColor(Color.WHITE);
        } else if(sensorValue < 12) {
            color = Color.parseColor("#3365ff");
            rootView.setBackgroundColor(color);
            textView.setTextColor(Color.WHITE);
            textViewLabel.setTextColor(Color.WHITE);
        } else if(sensorValue < 15) {
            color = Color.parseColor("#00cefc");
            rootView.setBackgroundColor(color);
            color = Color.parseColor("#00320c");
            textView.setTextColor(color);
            textViewLabel.setTextColor(color);
        } else if(sensorValue < 18) {
            color = Color.parseColor("#33ccc9");
            rootView.setBackgroundColor(color);
            color = Color.parseColor("#005760");
            textView.setTextColor(color);
            textViewLabel.setTextColor(color);
        } else if(sensorValue < 21) {
            color = Color.parseColor("#cdffc9");
            rootView.setBackgroundColor(color);
            color = Color.parseColor("#123d10");
            textView.setTextColor(color);
            textViewLabel.setTextColor(color);
        } else if(sensorValue < 24) {
            color = Color.parseColor("#369865");
            rootView.setBackgroundColor(color);
            color = Color.parseColor("#001700");
            textView.setTextColor(color);
            textViewLabel.setTextColor(color);
        }  else if(sensorValue < 27) {
            color = Color.parseColor("#ffff97");
            rootView.setBackgroundColor(color);
            color = Color.parseColor("#3b3901");
            textView.setTextColor(color);
            textViewLabel.setTextColor(color);
        }  else if(sensorValue < 30) {
            color = Color.parseColor("#fdcc02");
            rootView.setBackgroundColor(color);
            color = Color.parseColor("#210600");
            textView.setTextColor(color);
            textViewLabel.setTextColor(color);
        } else if(sensorValue < 33) {
            color = Color.parseColor("#ff9700");
            rootView.setBackgroundColor(color);
            color = Color.parseColor("#340000");
            textView.setTextColor(color);
            textViewLabel.setTextColor(color);
        }  else {
            color = Color.parseColor("#fe0000");
            rootView.setBackgroundColor(color);
            color = Color.parseColor("#ffd5c7");
            textView.setTextColor(color);
            textViewLabel.setTextColor(color);
        }
    }

    public void updateValue(int newValue) {
        updateImage(newValue);
        updateText(newValue);
    }

}